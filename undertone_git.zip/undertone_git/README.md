undertone
=========
This is a read me file

After we graduate: To get a more accurate color -> emotion list we crowd source it by making a game that has people select what emotion goes to the color in a "Family Fued"